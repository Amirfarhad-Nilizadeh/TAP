All generated input were invalid.
