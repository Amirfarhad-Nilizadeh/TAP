Only in the third run, one of the inputs was valid. Thus, we have a JUnit only for the third run.
