Only in the second run, one of the inputs was valid. Thus, we have a JUnit only for the second run.
