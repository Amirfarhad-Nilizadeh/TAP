All JUnits are the same. We used the same initial seed for all runs and generated inputs with initial seeds cover all branches. 
