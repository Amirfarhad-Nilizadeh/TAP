public class Fibonacci {
	Fibonacci() { }

	//@ requires 2 <= size && size <= 93; 	// 93 < size ==> Long Overflow
	Fibonacci(int size){ }
}
