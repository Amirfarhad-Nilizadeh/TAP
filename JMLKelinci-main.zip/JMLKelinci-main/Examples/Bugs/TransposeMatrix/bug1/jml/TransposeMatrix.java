public class TransposeMatrix {
       //@ requires 0 < matrix.length && matrix.length <= Integer.MAX_VALUE;
       //@ requires 0 < matrix[0].length && matrix[0].length <= Integer.MAX_VALUE;
       //@ requires (\forall int k; 0 <= k && k < matrix.length; matrix[k] != null);
       //@ requires (\forall int k; 0 <= k && k < matrix.length; matrix[0].length == matrix[k].length);
       public int[][] transposeMat(int[][] matrix)
       {
          return null;
       }
}

