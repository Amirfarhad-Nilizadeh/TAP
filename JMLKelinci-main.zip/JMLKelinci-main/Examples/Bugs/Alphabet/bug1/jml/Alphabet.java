public class Alphabet {
   public Alphabet(char c) { }
   //@ requires 0 <= op && op <= 4;
   public boolean[] driver(int op) { return null; }
}
