public class Smallest {
    //@ requires 0 <= a.length && a.length <= Integer.MAX_VALUE;
    static public int Smallest(int[] a) { return 0; }
}

