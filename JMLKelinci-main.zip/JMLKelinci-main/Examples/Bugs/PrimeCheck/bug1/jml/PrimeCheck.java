class PrimeCheck {
   //@ requires 1 < a && a <= Integer.MAX_VALUE; 
   public boolean isPrime(int a) { return true; }
}
