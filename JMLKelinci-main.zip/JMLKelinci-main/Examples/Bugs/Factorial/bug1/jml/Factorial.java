public class Factorial {
       //@ requires 0 <= n && n <= 20;
       public long factorial(int n) { return 0; }
}
