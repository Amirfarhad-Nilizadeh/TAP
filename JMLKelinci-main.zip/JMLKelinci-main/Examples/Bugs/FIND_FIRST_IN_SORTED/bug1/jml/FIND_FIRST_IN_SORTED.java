public class FIND_FIRST_IN_SORTED {
    //@ requires 0 <= arr.length && arr.length <= (Integer.MAX_VALUE/2)+1; 
    /*@ requires (\forall int j; 0 <= j && j < arr.length;
      @             (\forall int i; 0 <= i && i < j ; arr[i] <= arr[j])); @*/
    public static int find_first_in_sorted(int[] arr, int x) { return 0; }
}
