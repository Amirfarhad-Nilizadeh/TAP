JMLKelinci fuzzing process will not start by using shell scripts because this buggy program goes to a crash with its initial input.
However, the initial seed can reveal the bug by using RAC.
