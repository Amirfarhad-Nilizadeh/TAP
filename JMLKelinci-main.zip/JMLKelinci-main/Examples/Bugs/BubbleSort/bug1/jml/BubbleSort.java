public class BubbleSort { 
    //@ requires 0 < arr.length && arr.length < Integer.MAX_VALUE;
    int[] bubbleSort(int arr[]) { return null; } 
}
