public class GCD {
        //@ requires num1 != Integer.MAX_VALUE && num2 != Integer.MAX_VALUE && Integer.MIN_VALUE + 1 < num1 && Integer.MIN_VALUE + 1 < num2;
	public int gcd(int num1, int num2) throws IllegalArgumentException 
	{ return 0;}
	
}
