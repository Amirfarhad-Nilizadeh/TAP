public class Inverse {
    //@ requires 0 <= x.length && x.length <= Integer.MAX_VALUE;
    //@ requires 0 <= y.length && y.length <= Integer.MAX_VALUE;
    public static boolean Inverse(int[] x, int[] y) { return false; }
}
