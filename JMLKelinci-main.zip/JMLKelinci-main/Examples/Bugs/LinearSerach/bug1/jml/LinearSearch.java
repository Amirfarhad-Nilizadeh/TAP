    public class LinearSearch {
      //@ requires array.length < Integer.MAX_VALUE;
      public static int linearSearch(int search, int array[]) { return 0; }
    }
