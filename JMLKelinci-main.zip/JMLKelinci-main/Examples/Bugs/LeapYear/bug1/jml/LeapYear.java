public class LeapYear {
    //@ requires 0 < year && year <= Integer.MAX_VALUE;
    boolean isLeapYear(int year) {
	return false;
   }
}
