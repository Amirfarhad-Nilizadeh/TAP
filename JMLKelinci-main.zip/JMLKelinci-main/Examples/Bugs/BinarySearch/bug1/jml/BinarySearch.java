public class BinarySearch {
    //@ requires 0 <= arr.length && arr.length <= Integer.MAX_VALUE;
    //@ requires Integer.MIN_VALUE <= key && key <= Integer.MAX_VALUE;
    //@ requires \forall int j; 0 <= j && j < arr.length; \forall int i; 0 <= i && i < j ;arr[i] <= arr[j];
    public static int Binary(int[] arr, int key) {return 0;}
}
