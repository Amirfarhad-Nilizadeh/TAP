public class LCM {
    //@ requires Integer.MIN_VALUE < num1 && num1 <= Integer.MAX_VALUE;
    //@ requires Integer.MIN_VALUE < num2 && num2 <= Integer.MAX_VALUE;
    public int lcm(int num1, int num2) { return 0; }
}
