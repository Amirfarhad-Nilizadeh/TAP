class FindInArray {
     //@ requires 0 <= inputArr.length;
     FindInArray(int inputArr[]) { } 

     //@ requires 0 <= inputArr.length;
     FindInArray(int inputArr[], int key) { } 
}
