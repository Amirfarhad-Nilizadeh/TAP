public class CombinationPermutation {
	//@ requires 0 <= n && n <= 20 && 0 <= r && r <= n;
	public long select (int n, int r, boolean flag) { return 0; }
}

