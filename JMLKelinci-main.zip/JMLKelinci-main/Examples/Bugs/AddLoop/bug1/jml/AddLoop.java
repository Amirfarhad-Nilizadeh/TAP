public class AddLoop {
    //@ requires Integer.MIN_VALUE <= x + y && x + y <= Integer.MAX_VALUE && y != Integer.MIN_VALUE;
    public static int AddLoop(int x, int y) { return 0; }
}

