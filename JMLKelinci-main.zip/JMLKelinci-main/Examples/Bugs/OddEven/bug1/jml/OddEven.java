public class OddEven {	

	 public /*@ pure @*/ boolean isEven(int x) { 
         	return true;
       	 } 

	 public /*@ pure @*/ boolean isOdd(int x) { 
         	return true;
       	 } 
}
