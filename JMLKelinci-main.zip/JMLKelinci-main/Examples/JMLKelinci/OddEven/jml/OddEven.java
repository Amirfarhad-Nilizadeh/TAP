public class OddEven {	
	 public boolean isEven(int x) { return true;} 
	 public boolean isOdd(int x) { return true;} 
}
